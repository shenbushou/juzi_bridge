/* 手气不错 · Arena 一键新对话 —— 后台编排
 * 职责：保存任务状态、必要时把标签页导航到 Arena 首页、页面加载完后唤起内容脚本继续执行。
 * v2.2：内容脚本就绪时主动认领未完成任务（不再只依赖 tabs.onUpdated），并给任务加总超时。
 */
'use strict';

const HOME_URL = 'https://arena.ai/';
const JOB_KEY = 'luckyJob';
const MAX_NAV = 5;
const JOB_TIMEOUT_MS = 150000;   // 任务总超时：到点一定落到 error，不会永远“进行中”

const isArenaUrl = (url) => /^https:\/\/([a-z0-9-]+\.)*arena\.ai(\/|$)/i.test(url || '');

const readySent = Object.create(null);

async function getJob() {
  try {
    const bag = await chrome.storage.local.get(JOB_KEY);
    return bag && bag[JOB_KEY] ? bag[JOB_KEY] : null;
  } catch (_) {
    return null;
  }
}

async function setJob(job) {
  try {
    await chrome.storage.local.set({ [JOB_KEY]: job });
  } catch (_) {}
}

async function patchJob(patch) {
  const job = (await getJob()) || {};
  await setJob(Object.assign({}, job, patch, { updatedAt: Date.now() }));
}

async function setBadge(state) {
  const map = {
    running: { text: '…', color: '#1a4fe0' },
    ok: { text: '✓', color: '#1f9d55' },
    error: { text: '!', color: '#d93025' },
    idle: { text: '', color: '#1a4fe0' }
  };
  const item = map[state] || map.idle;
  try {
    await chrome.action.setBadgeText({ text: item.text });
    await chrome.action.setBadgeBackgroundColor({ color: item.color });
  } catch (_) {}
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 往页面发送“开始跑”指令；内容脚本还没注入时用 scripting 兜底注入。 */
async function sendRun(tabId, attempts = 24) {
  for (let i = 0; i < attempts; i++) {
    try {
      const res = await chrome.tabs.sendMessage(tabId, { type: 'LUCKY_RUN' });
      if (res && res.ok) return true;
    } catch (_) {
      if (i === 1) {
        try {
          await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
        } catch (_) {}
      }
    }
    await sleep(500);
  }
  return false;
}

async function navigate(tabId, url) {
  try {
    await chrome.tabs.update(tabId, { url: url || HOME_URL });
    return true;
  } catch (_) {
    return false;
  }
}

async function startJob(tab) {
  let target = tab;
  if (!target) {
    const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
    target = active;
  }
  const startedAt = Date.now();
  await setJob({
    state: 'running',
    step: '准备中…',
    startedAt,
    updatedAt: Date.now(),
    navCount: 0
  });
  setBadge('running');
  if (!target || !target.id) {
    await patchJob({ state: 'error', step: '找不到可用的标签页，请打开 arena.ai 后重试' });
    setBadge('error');
    return;
  }

  armJobTimeout(startedAt);

  if (!isArenaUrl(target.url)) {
    await navigate(target.id, HOME_URL);
    return; // 页面加载完成后由 tabs.onUpdated / LUCKY_READY 续跑
  }
  await sendRun(target.id);
}

/** 任务总超时：只有同一批任务（startedAt 相同）还在跑时才收尾。 */
function armJobTimeout(startedAt) {
  setTimeout(async () => {
    const job = await getJob();
    if (!job || job.state !== 'running' || job.startedAt !== startedAt) return;
    await patchJob({ state: 'error', step: '超时：扩展没有完成，可再点一次重试' });
    setBadge('error');
  }, JOB_TIMEOUT_MS);
}

async function navigateAndResume(tabId, url) {
  const job = (await getJob()) || {};
  const navCount = (job.navCount || 0) + 1;
  if (navCount > MAX_NAV) {
    await patchJob({ state: 'error', step: '页面跳转次数过多，已停止' });
    setBadge('error');
    return;
  }
  await patchJob({ navCount, state: 'running' });
  await navigate(tabId, url || HOME_URL);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return;
  const tab = sender && sender.tab;

  if (msg.type === 'LUCKY_START') {
    startJob(tab).catch((e) => {
      patchJob({ state: 'error', step: String((e && e.message) || e) });
      setBadge('error');
    });
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'LUCKY_READY') {
    // 页面（重新）加载完：若还有未完成的任务，把 run 交给刚就绪的页面
    const tabId = tab && tab.id;
    getJob()
      .then((job) => {
        if (!job || job.state !== 'running' || !tabId) return;
        if (!isArenaUrl(tab.url)) return;
        const now = Date.now();
        if (readySent[tabId] && now - readySent[tabId] < 3000) return;
        readySent[tabId] = now;
        sendRun(tabId, 10);
      })
      .catch(() => {});
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'LUCKY_NAVIGATE') {
    if (tab && tab.id) {
      navigateAndResume(tab.id, msg.url).catch(() => {});
    }
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'LUCKY_STATE') {
    patchJob({ step: msg.step || '', status: msg.status || 'running' });
    setBadge(msg.status === 'error' ? 'error' : msg.status === 'ok' ? 'ok' : 'running');
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'LUCKY_FINISH') {
    patchJob({ state: msg.state || 'idle', step: msg.step || '' });
    setBadge(msg.state === 'ok' ? 'ok' : msg.state === 'error' ? 'error' : 'idle');
    sendResponse({ ok: true });
    return true;
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (!info || info.status !== 'complete') return;
  if (!tab || !isArenaUrl(tab.url)) return;
  const job = await getJob();
  if (!job || job.state !== 'running') return;
  const now = Date.now();
  if (readySent[tabId] && now - readySent[tabId] < 3000) return;
  readySent[tabId] = now;
  sendRun(tabId, 12);
});

chrome.runtime.onInstalled.addListener(() => {
  setBadge('idle');
});
