/* 手气不错 · Arena 一键新对话 —— 页面端脚本（v2.2：就地新对话 + 防卡死看门狗 + 每步验证与重试）
 *
 * 与 v1 的区别：
 *  1. 不靠固定 sleep 猜时间：每个动作之后都 waitUntil 校验真实状态，不通过就重试。
 *  2. 打字分块写入，逐块回读长度，写不进去就换更细的方式，绝不带着空输入框去发送。
 *  3. 发送前后都有确认：先等发送按钮真的可用，发出后等「会话页跳转 / 消息气泡出现 / 输入框清空」。
 *  4. Agree 是动态判断：只有页面上真的出现同意弹窗才点，点完还要验证它真的消失。
 *  5. 已在对话页时，页面若自带 New Chat 就地点击（不整页重载）；没有这个按钮才回首页。
 *  6. 防卡死：每一步都有阶段预算，超出就换招或中止；另有一个总看门狗，超时一定收尾，按钮不会一直转。
 *  7. 阶段级重试：等输入框 / 切 Agent / 写提示词 / 发送 各有多轮重试，每轮之间先点掉 Agree 再重来。
 */
(function () {
  'use strict';

  if (window.__arenaLuckyLoaded) return;
  window.__arenaLuckyLoaded = true;

  const PROMPT =
    '创建一个新 HTML，使用 SVG 绘制一个鹈鹕骑自行车的 2D 动画。页面中只展示自动播放、循环播放的动画，不要解释、说明文字、按钮、菜单或任何交互功能，不需要任何测试，直接显示在聊天窗口';
  const PROMPT_MARK = '使用 SVG 绘制一个鹈鹕骑自行车';
  const HOME_URL = 'https://arena.ai/';
  const MAX_NAV = 5;
  const HARD_LIMIT_MS = 120000;   // 一次点击的硬上限：到点一定收尾，绝不让按钮一直转

  const AGREE_RE = /^(agree|accept(\s+all)?|i\s+agree|got\s+it|allow\s+all|同意|我同意|全部接受|接受|知道了)$/i;
  const MODE_RE = /^(battle|direct\s*chat|side\s*by\s*side|chat|agent|模型|模式)$/i;
  const AGENT_RE = /^agent\b/i;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const jitter = (a, b) => a + Math.random() * (b - a);
  const all = (sel) => Array.prototype.slice.call(document.querySelectorAll(sel));
  const txt = (el) => (el && el.textContent ? el.textContent.replace(/\s+/g, ' ').trim() : '');

  function vis(el) {
    if (!el || !el.getBoundingClientRect) return false;
    const r = el.getBoundingClientRect();
    if (r.width <= 2 || r.height <= 2) return false;
    const st = window.getComputedStyle(el);
    if (st.visibility === 'hidden' || st.display === 'none' || Number(st.opacity || '1') <= 0.05) return false;
    return true;
  }

  const isArena = () => /(^|\.)arena\.ai$/i.test(location.hostname);

  /* ============================================================ 基础工具 */

  /** 轮询直到 fn() 返回真值；返回该值，超时返回 null。 */
  async function waitUntil(fn, timeoutMs, intervalMs, label) {
    const start = Date.now();
    const iv = intervalMs || 150;
    for (;;) {
      if (expired()) {
        if (label) debug(label + ' 已中止');
        return null;
      }
      let v = null;
      try {
        v = fn();
      } catch (_) {}
      if (v) return v;
      if (Date.now() - start >= (timeoutMs || 8000)) {
        if (label) debug(label + ' 未达成（超时）');
        return null;
      }
      await sleep(iv);
    }
  }

  /** 等某个元素/状态消失。 */
  async function waitGone(fn, timeoutMs, intervalMs) {
    const start = Date.now();
    for (;;) {
      let v = null;
      try {
        v = fn();
      } catch (_) {}
      if (!v) return true;
      if (Date.now() - start >= (timeoutMs || 5000)) return false;
      await sleep(intervalMs || 150);
    }
  }

  function debug(msg) {
    try {
      console.debug('[手气不错]', msg);
    } catch (_) {}
  }

  /* ======================================================== 中止与看门狗 */

  let aborted = false;
  let runDeadline = 0;
  let watchdogTimer = 0;
  /** 是否该收手：被看门狗中止，或已过总时限。所有轮询都会看它。 */
  const expired = () => aborted || (runDeadline > 0 && Date.now() > runDeadline);

  function storageGet(key) {
    return new Promise((resolve) => {
      try {
        const p = chrome.storage.local.get(key, (bag) => resolve((bag && bag[key]) || null));
        if (p && typeof p.then === 'function') {
          p.then((bag) => resolve((bag && bag[key]) || null)).catch(() => resolve(null));
        }
      } catch (_) {
        resolve(null);
      }
    });
  }

  function sendBackground(msg) {
    try {
      if (chrome && chrome.runtime && chrome.runtime.sendMessage) chrome.runtime.sendMessage(msg);
    } catch (_) {}
  }

  /* ============================================================== 小浮窗 */

  let ui = null;
  let hideTimer = 0;

  function mountUI() {
    if (document.getElementById('arena-lucky-root')) {
      ui = {
        root: document.getElementById('arena-lucky-root'),
        btn: document.getElementById('arena-lucky-btn'),
        label: document.getElementById('arena-lucky-label'),
        status: document.getElementById('arena-lucky-status')
      };
      return;
    }

    const style = document.createElement('style');
    style.id = 'arena-lucky-style';
    style.textContent = `
#arena-lucky-root{position:fixed;right:24px;bottom:24px;z-index:2147483647;display:flex;flex-direction:column;align-items:flex-end;gap:10px;
font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif;pointer-events:none}
#arena-lucky-root *{box-sizing:border-box}
#arena-lucky-btn{pointer-events:auto;display:inline-flex;align-items:center;gap:9px;border:0;outline:none;cursor:pointer;
padding:13px 24px;border-radius:999px;color:#fff;font-size:15px;font-weight:700;letter-spacing:.3px;line-height:1;
background:linear-gradient(135deg,#3d7bff 0%,#1a4fe0 100%);
box-shadow:0 10px 24px rgba(26,79,224,.38),0 2px 6px rgba(26,79,224,.28),inset 0 1px 0 rgba(255,255,255,.28);
transition:transform .16s ease,box-shadow .16s ease,filter .16s ease;user-select:none;-webkit-user-select:none}
#arena-lucky-btn:hover{transform:translateY(-1px);filter:brightness(1.06)}
#arena-lucky-btn:active{transform:translateY(0) scale(.985)}
#arena-lucky-btn.is-busy{cursor:progress;filter:saturate(.9)}
#arena-lucky-spin{width:14px;height:14px;border:2px solid rgba(255,255,255,.45);border-top-color:#fff;border-radius:50%;
display:none;animation:arena-lucky-spin .8s linear infinite}
#arena-lucky-btn.is-busy #arena-lucky-spin{display:inline-block}
@keyframes arena-lucky-spin{to{transform:rotate(360deg)}}
#arena-lucky-status{pointer-events:none;max-width:300px;padding:9px 13px;border-radius:12px;font-size:12.5px;line-height:1.5;
color:#fff;background:rgba(17,24,39,.92);box-shadow:0 8px 22px rgba(15,23,42,.28);opacity:0;transform:translateY(6px);
transition:opacity .2s ease,transform .2s ease;word-break:break-word}
#arena-lucky-status.is-show{opacity:1;transform:translateY(0)}
#arena-lucky-status.is-ok{background:rgba(31,157,85,.95)}
#arena-lucky-status.is-error{background:rgba(217,48,37,.95)}
@media (max-width:520px){#arena-lucky-btn{padding:11px 18px;font-size:14px}#arena-lucky-root{right:14px;bottom:16px}}
`;
    (document.head || document.documentElement).appendChild(style);

    const root = document.createElement('div');
    root.id = 'arena-lucky-root';
    root.innerHTML =
      '<button id="arena-lucky-btn" type="button" title="在当前页开一个新对话（没有 New Chat 按钮才回首页），切到 Agent 模式并发送鹈鹕动画提示词">' +
      '<span id="arena-lucky-spin"></span><span id="arena-lucky-label">手气不错</span></button>' +
      '<div id="arena-lucky-status" role="status" aria-live="polite"></div>';
    (document.body || document.documentElement).appendChild(root);

    ui = {
      root,
      btn: root.querySelector('#arena-lucky-btn'),
      label: root.querySelector('#arena-lucky-label'),
      status: root.querySelector('#arena-lucky-status')
    };

    ui.btn.addEventListener('click', () => {
      if (running) {
        report('正在执行，请稍候…', 'running', true);
        return;
      }
      sessionDone = false;
      report('已点击，正在准备…', 'running');
      sendBackground({ type: 'LUCKY_START' });
    });
  }

  function setBusy(busy) {
    if (!ui) return;
    ui.btn.classList.toggle('is-busy', !!busy);
    ui.label.textContent = busy ? '正在执行…' : '手气不错';
  }

  function report(message, kind, keep) {
    if (!ui) return;
    const st = ui.status;
    st.textContent = message || '';
    st.classList.add('is-show');
    st.classList.toggle('is-ok', kind === 'ok');
    st.classList.toggle('is-error', kind === 'error');
    clearTimeout(hideTimer);
    if (!keep && kind !== 'error') hideTimer = setTimeout(() => st.classList.remove('is-show'), 6000);
    sendBackground({ type: 'LUCKY_STATE', step: message || '', status: kind || 'running' });
  }

  const finish = (state, step) => sendBackground({ type: 'LUCKY_FINISH', state, step: step || '' });

  /** 跑一个阶段：状态栏立刻显示它，超过 3 秒后每秒追加已等秒数（避免看起来卡死）。 */
  async function withProgress(label, fn) {
    report(label + '…');
    const t0 = Date.now();
    let shown = 0;
    const tick = setInterval(() => {
      if (!ui || !ui.status) return;
      const sec = Math.floor((Date.now() - t0) / 1000);
      if (sec >= 3 && sec > shown) {
        shown = sec;
        ui.status.textContent = label + '…（' + sec + ' 秒）';
        ui.status.classList.add('is-show');
      }
    }, 1000);
    try {
      return await fn();
    } finally {
      clearInterval(tick);
    }
  }

  /** 阶段之间的小急救：把可能挡路的 Agree 点掉。 */
  async function recover() {
    if (expired()) return;
    await dismissAgreeIfPresent(0);
    await sleep(120);
  }

  /** 关掉可能没关的菜单/弹层（Escape 只发给当前焦点与 document）。 */
  async function escapeClose() {
    try {
      const opts = { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true };
      const target = document.activeElement || document.body;
      if (target) target.dispatchEvent(new KeyboardEvent('keydown', opts));
      document.dispatchEvent(new KeyboardEvent('keydown', opts));
    } catch (_) {}
    await sleep(220);
  }

  /** 同一件事最多试 attempts 次；每次失败前先 recover()，任一成功立刻返回。 */
  async function retry(label, attempts, fn) {
    for (let i = 1; i <= attempts; i++) {
      if (expired()) return null;
      let v = null;
      try {
        v = await fn(i);
      } catch (e) {
        debug(label + ' 第 ' + i + ' 轮出错：' + ((e && e.message) || e));
      }
      if (v) return v;
      if (i < attempts) {
        debug(label + ' 第 ' + i + ' 轮没成功，准备重试');
        await recover();
      }
    }
    return null;
  }

  /* ============================================================ DOM 工具 */

  function realClick(el) {
    if (!el) return false;
    try {
      el.scrollIntoView({ block: 'center', inline: 'center' });
    } catch (_) {}
    const r = el.getBoundingClientRect();
    const opts = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      button: 0,
      buttons: 1,
      clientX: Math.round(r.left + r.width / 2),
      clientY: Math.round(r.top + r.height / 2)
    };
    ['pointerover', 'pointerenter', 'pointermove', 'pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach((t) => {
      const Ctor = t.indexOf('pointer') === 0 ? window.PointerEvent || MouseEvent : MouseEvent;
      try {
        el.dispatchEvent(new Ctor(t, opts));
      } catch (_) {}
    });
    try {
      el.click();
      return true;
    } catch (_) {
      try {
        return el.dispatchEvent(new MouseEvent('click', opts));
      } catch (_) {
        return false;
      }
    }
  }

  function findEditor() {
    const prefer = all(
      'div.editor-content [contenteditable="true"], .ProseMirror[contenteditable="true"], .tiptap[contenteditable="true"]'
    ).filter(vis);
    for (let i = 0; i < prefer.length; i++) {
      const r = prefer[i].getBoundingClientRect();
      if (r.width > 60 && r.height > 14) return prefer[i];
    }
    const any = all('[contenteditable="true"], textarea').filter(vis);
    for (let i = 0; i < any.length; i++) {
      const r = any[i].getBoundingClientRect();
      if (r.width > 60 && r.height > 14) return any[i];
    }
    return null;
  }

  function editorLength(el) {
    if (!el) return 0;
    const v = el.tagName === 'TEXTAREA' ? el.value : el.innerText || el.textContent || '';
    return v.replace(/\u00a0/g, ' ').trim().length;
  }

  function composerOf(editor) {
    let node = editor;
    for (let i = 0; i < 8 && node; i++) {
      node = node.parentElement;
      if (!node) break;
      if (node.getBoundingClientRect().width > 200 && node.querySelector('button, [role="button"]')) return node;
    }
    return editor.closest('form') || null;
  }

  function findSendButton(editor) {
    const composer = composerOf(editor);
    const pool = (composer ? all('button, [role="button"]').filter((b) => composer.contains(b)) : all('button, [role="button"]'))
      .filter(vis);
    const score = (b) => {
      const meta =
        (b.getAttribute('aria-label') || '') + ' ' + (b.getAttribute('title') || '') + ' ' + (b.getAttribute('data-testid') || '');
      if (/send/i.test(meta)) return 100;
      if (/^(send|send message|发送)$/i.test(txt(b))) return 90;
      if (b.getAttribute('type') === 'submit') return 70;
      const metaLower = (meta + ' ' + txt(b)).toLowerCase();
      if (b.querySelector('svg') && !/attach|upload|file|image|photo|mic|voice|audio|plus|menu|mode|model|battle|agent|tool|setting|search/.test(metaLower))
        return 25;
      return 0;
    };
    const ranked = pool
      .map((b) => ({ b, s: score(b), r: b.getBoundingClientRect() }))
      .filter((x) => x.s > 0)
      .sort((a, b) => b.s - a.s || b.r.left - a.r.left);
    return ranked.length ? ranked[0].b : null;
  }

  function isDisabled(el) {
    if (!el) return true;
    if (el.disabled === true) return true;
    if (el.getAttribute('aria-disabled') === 'true') return true;
    const st = window.getComputedStyle(el);
    return Number(st.opacity || '1') < 0.35 || st.pointerEvents === 'none';
  }

  function findModeButton(editor) {
    const send = findSendButton(editor);
    const row = send ? send.parentElement : null;
    const cands = all('button, [role="button"], [role="combobox"]').filter(vis);

    const named = cands.filter((b) => MODE_RE.test(txt(b)));
    if (named.length) {
      const inRow = row ? named.filter((b) => row.contains(b)) : [];
      return inRow[0] || named[0];
    }
    if (row) {
      const inRow = Array.prototype.slice
        .call(row.querySelectorAll('button, [role="button"]'))
        .filter((b) => vis(b) && b !== send);
      if (inRow.length) return inRow[0];
    }
    const aria = cands.filter((b) =>
      /mode|model|agent|battle|模式/i.test((b.getAttribute('aria-label') || '') + ' ' + (b.getAttribute('title') || ''))
    );
    return aria.length ? aria[0] : null;
  }

  function findAgentMenuItem() {
    const roleSel = '[role="menuitem"], [role="menuitemradio"], [role="menuitemcheckbox"], [role="option"]';
    let cands = all(roleSel).filter((el) => vis(el) && AGENT_RE.test(txt(el)));
    if (!cands.length) {
      cands = all('button, div, span, li').filter(
        (el) => vis(el) && txt(el) && txt(el).length <= 24 && AGENT_RE.test(txt(el))
      );
      cands = cands.filter((el) => !Array.prototype.some.call(el.children, (c) => AGENT_RE.test(txt(c))));
    }
    if (!cands.length) return null;
    cands.sort((a, b) => txt(a).length - txt(b).length);
    return cands[0];
  }

  function currentModeLabel(editor) {
    const btn = findModeButton(editor);
    return btn ? txt(btn) : '';
  }

  function agentSelected(editor) {
    if (AGENT_RE.test(currentModeLabel(editor))) return true;
    const checked = all('[role="menuitemradio"], [role="radio"], [aria-checked="true"]').filter(
      (el) => vis(el) && AGENT_RE.test(txt(el))
    );
    return checked.length > 0;
  }

  /* ========================================================== Agree 弹窗 */

  function dialogRoot() {
    const dialogs = all('[role="dialog"], [role="alertdialog"], dialog[open]').filter(vis);
    for (let i = 0; i < dialogs.length; i++) {
      const t = txt(dialogs[i]);
      if (AGREE_RE.test(t) || /terms|privacy|continue|agree|cookie/i.test(t)) return dialogs[i];
    }
    return dialogs[0] || null;
  }

  function findAgreeButton() {
    const root = dialogRoot() || document;
    const pool = all('button, [role="button"], a').filter((el) => vis(el) && root.contains(el));
    const isAgree = (el) => AGREE_RE.test(txt(el)) || AGREE_RE.test((el.getAttribute('aria-label') || '').trim());
    return pool.find(isAgree) || null;
  }

  /** 只有在页面上真的出现同意按钮时才点；点完验证它消失。返回是否处理过。 */
  async function dismissAgreeIfPresent(waitMs) {
    let btn = waitMs ? await waitUntil(findAgreeButton, waitMs, 120) : findAgreeButton();
    if (!btn) return false;
    for (let attempt = 0; attempt < 3 && btn; attempt++) {
      debug('发现 Agree 弹窗，点击：' + txt(btn).slice(0, 20));
      realClick(btn);
      await sleep(350);
      const gone = await waitGone(() => {
        const again = findAgreeButton();
        return again && vis(again) ? again : null;
      }, 4000, 150);
      if (gone) return true;
      btn = findAgreeButton();
    }
    debug('Agree 弹窗点了 3 次仍未消失');
    return false;
  }

  /* ============================================================ 登录判定 */

  function hasLoginUI() {
    const needsLogin = all('button, a').some(
      (b) => vis(b) && /^(log\s*in|sign\s*in|登录|登入)$/i.test(txt(b))
    );
    if (needsLogin) return true;
    const dlg = document.querySelector('[role="dialog"]');
    if (dlg && vis(dlg) && dlg.querySelector('input[type="password"], input[type="email"], input[name="email"]')) return true;
    return false;
  }

  const isLoggedIn = () => !hasLoginUI() && !!findEditor();

  /* ============================================================ 输入文字 */

  function focusEditor(editor) {
    try {
      editor.scrollIntoView({ block: 'center' });
    } catch (_) {}
    realClick(editor);
    try {
      editor.focus();
    } catch (_) {}
  }

  async function editorFocused(editor) {
    return waitUntil(() => {
      const ae = document.activeElement;
      return ae && (ae === editor || editor.contains(ae)) ? ae : null;
    }, 3000, 100);
  }

  function clearEditor(editor) {
    try {
      editor.focus();
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(editor);
      sel.removeAllRanges();
      sel.addRange(range);
      document.execCommand('delete', false, null);
      return true;
    } catch (_) {
      return false;
    }
  }

  function editorText(el) {
    if (!el) return '';
    const v = el.tagName === 'TEXTAREA' ? el.value : el.innerText || el.textContent || '';
    return v.replace(/\u00a0/g, ' ');
  }

  /** 分块插入；每块之后回读长度，被吞掉就拆成单字符再补。 */
  async function insertChunks(editor, text) {
    const CHUNK = 14;
    for (let i = 0; i < text.length; i += CHUNK) {
      const piece = text.slice(i, i + CHUNK);
      const before = editorText(editor).length;
      try {
        document.execCommand('insertText', false, piece);
      } catch (_) {}
      await sleep(jitter(60, 105));
      if (editorText(editor).length <= before) {
        for (let k = 0; k < piece.length; k++) {
          try {
            document.execCommand('insertText', false, piece[k]);
          } catch (_) {}
          await sleep(jitter(12, 26));
        }
        await sleep(110);
      }
    }
  }

  /** 写入并校验：以「当前内容是目标前缀」为基准补齐缺失部分，最多三轮。 */
  async function typeIntoEditor(editor, text) {
    focusEditor(editor);
    const focused = await editorFocused(editor);
    if (!focused) return { ok: false, reason: '输入框没有获得焦点', len: 0, total: text.length };
    await sleep(220);

    clearEditor(editor);
    await waitGone(() => editorText(editor).length > 0, 2500, 100);
    await insertChunks(editor, text);

    for (let attempt = 0; attempt < 3; attempt++) {
      const cur = editorText(editor);
      if (cur === text) return { ok: true, len: cur.length, total: text.length };
      if (text.startsWith(cur)) {
        debug('补齐缺失的 ' + (text.length - cur.length) + ' 个字符');
        await insertChunks(editor, text.slice(cur.length));
      } else {
        debug('内容与目标不一致，清空重写');
        clearEditor(editor);
        await sleep(180);
        await insertChunks(editor, text);
      }
      await sleep(200);
    }

    const cur = editorText(editor);
    return { ok: cur === text, len: cur.length, total: text.length };
  }

  /* ============================================================== 发送区 */

  function countInBody(mark) {
    const body = document.body && document.body.innerText ? document.body.innerText : '';
    if (!mark) return 0;
    let n = 0;
    let from = 0;
    for (;;) {
      const i = body.indexOf(mark, from);
      if (i === -1) break;
      n += 1;
      from = i + mark.length;
    }
    return n;
  }

  function sentConfirmed(startPath) {
    if (/\/agent\//.test(location.pathname)) return true;
    if (startPath && location.pathname !== startPath) return true;
    const editor = findEditor();
    const empty = !editor || editorLength(editor) < 10;
    return empty && countInBody(PROMPT_MARK) >= 1;
  }

  async function pressEnter(editor) {
    focusEditor(editor);
    await sleep(150);
    const targets = [editor, document];
    let prevented = false;
    targets.forEach((target) => {
      ['keydown', 'keypress', 'keyup'].forEach((type) => {
        try {
          const ev = new KeyboardEvent(type, {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true,
            cancelable: true,
            composed: true,
            isComposing: false
          });
          target.dispatchEvent(ev);
          if (type === 'keydown' && ev.defaultPrevented) prevented = true;
        } catch (_) {}
      });
    });
    return prevented;
  }

  /** 点发送按钮；点完等状态确认，返回是否成功发出。 */
  async function trySendOnce(editor, startPath) {
    const btn = findSendButton(editor);
    if (btn) {
      const enabled = await waitUntil(() => !isDisabled(btn), 6000, 150);
      if (enabled) {
        realClick(btn);
        const ok = !!(await waitUntil(() => sentConfirmed(startPath), 9000, 250));
        if (ok) return { ok: true, how: 'button' };
        debug('点了发送按钮但没确认到已发送');
      } else {
        debug('发送按钮仍处于禁用状态');
      }
    }
    await pressEnter(editor);
    const okEnter = !!(await waitUntil(() => sentConfirmed(startPath), 9000, 250));
    if (okEnter) return { ok: true, how: 'enter' };
    return { ok: false };
  }

  /* ============================================================== 新对话 */

  const NEW_CHAT_EXACT = /^(new chat|new conversation|新对话|新建对话|新聊天|开始新对话)$/i;
  const NEW_CHAT_LOOSE = /new\s*chat|new\s*conversation|新对话|新建对话|新聊天/i;

  /** 页面上可见的「New Chat」控件；没有就返回 null（只认按钮/链接，不认正文里的文字）。 */
  function findNewChatButton() {
    const pool = all('button, a, [role="button"], [role="link"]').filter(vis);
    return (
      pool.find((el) => {
        const label = (el.getAttribute('aria-label') || '').trim();
        const title = (el.getAttribute('title') || '').trim();
        const testid = ((el.getAttribute('data-testid') || '') + ' ' + (el.getAttribute('data-test') || '')).trim();
        return (
          NEW_CHAT_EXACT.test(txt(el)) ||
          NEW_CHAT_LOOSE.test(label) ||
          NEW_CHAT_LOOSE.test(title) ||
          /new[-_ ]?chat|new[-_ ]?conversation/i.test(testid)
        );
      }) || null
    );
  }

  async function ensureNewChat(editor) {
    if (editorLength(editor) === 0) return true;
    const btn = findNewChatButton();
    if (!btn) return false;
    realClick(btn);
    const cleared = await waitGone(() => {
      const ed = findEditor();
      return ed && editorLength(ed) > 0 ? ed : null;
    }, 5000, 150);
    return !!cleared;
  }

  /** 就在当前页点 New Chat 开新对话：成功返回 true（无需整页重载）；点不动返回 false。 */
  async function startNewChatInPlace() {
    const before = location.pathname;
    // 侧栏可能比正文晚渲染：先给 10 秒；还找不到，后面每轮再补找一次
    let btn = await waitUntil(findNewChatButton, 10000, 200, 'New Chat 按钮');
    for (let attempt = 1; attempt <= 3; attempt++) {
      if (expired()) return false;
      if (!btn) {
        await sleep(600);
        btn = findNewChatButton();
        if (!btn) break;
      }
      await dismissAgreeIfPresent(0);
      report('已在对话页，点击 New Chat…' + (attempt > 1 ? '（第 ' + attempt + ' 次）' : ''));
      realClick(btn);
      // 只有路由真的换了才算新对话：停在 '/'，或路径变了且输入框已空。
      const ready = await waitUntil(() => {
        if (location.pathname === '/') return true;
        if (location.pathname !== before) {
          const ed = findEditor();
          if (ed && editorLength(ed) === 0) return true;
        }
        return null;
      }, 5000, 150, 'New Chat 后页面没有切到新对话（第 ' + attempt + ' 次）');
      if (ready) return true;
      btn = findNewChatButton();
      if (!btn) await sleep(400);
    }
    debug('New Chat 点了 3 次仍未切换路由');
    return false;
  }

  /* ============================================================== 主流程 */

  let running = false;
  let sessionDone = false;

  /** 看门狗：不管卡在哪个 await，到点都强制收尾并给用户一句话。 */
  function armWatchdog(ms) {
    clearTimeout(watchdogTimer);
    watchdogTimer = setTimeout(() => {
      if (!running) return;
      aborted = true;
      debug('总时限 ' + Math.round(ms / 1000) + ' 秒已到，中止本次执行');
      report('整体超时（' + Math.round(ms / 1000) + ' 秒），已中止。可再点一次重试', 'error');
      finish('error', '整体超时');
    }, ms);
  }

  function disarmWatchdog() {
    clearTimeout(watchdogTimer);
    watchdogTimer = 0;
  }

  async function run() {
    if (running || sessionDone) return;
    running = true;
    aborted = false;
    runDeadline = Date.now() + HARD_LIMIT_MS;
    setBusy(true);
    armWatchdog(HARD_LIMIT_MS + 4000);
    let navigated = false;

    try {
      if (!isArena()) throw new Error('当前页面不是 arena.ai');

      /* 1. 登录 + 起始 Agree：先给弹窗一次机会，再判断登录（有输入框就不算未登录） */
      await withProgress('检查页面状态', async () => {
        await dismissAgreeIfPresent(2000);
        if (hasLoginUI() && !findEditor()) {
          await sleep(1200);
          await dismissAgreeIfPresent(0);
          if (hasLoginUI() && !findEditor()) throw new Error('未检测到 Arena 登录状态，请先登录后重试');
        }
      });
      if (expired()) throw new Error('整体超时，已中止');

      /* 2. 新对话：当前页有 New Chat 就地点（最多试 3 次），没有才回首页 */
      if (location.pathname !== '/') {
        const fresh = await startNewChatInPlace();
        if (!fresh) {
          if (location.pathname !== '/') {
            report('没有可用的 New Chat，回到 Arena 首页…');
            sendBackground({ type: 'LUCKY_NAVIGATE', url: HOME_URL });
            navigated = true;
            return;
          }
          debug('New Chat 不可用，但已经在首页，继续');
        }
      }

      /* 3. 等输入框：3 轮，每轮之间点掉 Agree（页面有时被弹窗挡住不渲染） */
      let editor = await withProgress('等待输入框', () =>
        retry('输入框', 3, async (n) => {
          if (n > 1) {
            await dismissAgreeIfPresent(0);
            await sleep(250);
          }
          return await waitUntil(findEditor, 6000, 250, '输入框');
        })
      );

      if (!editor) {
        if (hasLoginUI()) throw new Error('未检测到 Arena 登录状态，请先登录后重试');
        if (location.pathname !== '/') {
          // 兜底：换整页回首页再续跑（这是唯一还会“开新页面”的情况）
          report('没找到输入框，回首页重试…', 'running', true);
          sendBackground({ type: 'LUCKY_NAVIGATE', url: HOME_URL });
          navigated = true;
          return;
        }
        throw new Error('没有找到 Arena 输入框：页面没加载完或被拦截，请刷新后重试');
      }

      /* 4. 确保是新对话（若输入框里还有旧内容，再点一次 New Chat） */
      if (editorLength(editor) > 0) {
        report('确保是新对话…');
        const fresh = await retry('清理输入框', 2, async () => await ensureNewChat(findEditor() || editor));
        if (!fresh) debug('输入框里原本有内容，且没找到新对话按钮，继续使用当前输入框');
        editor = (await waitUntil(findEditor, 8000, 250)) || findEditor() || editor;
      }

      // 发送确认以这里为准：就地 New Chat 会改路径，不能拿进入页面时的路径当基线
      const sendPath = location.pathname;

      /* 5. Agent 模式：点前看清状态，点后验证；菜单没出来就 Escape 再来 */
      report('切换到 Agent 模式…');
      let switched = agentSelected(editor);
      let lastLabel = currentModeLabel(editor);
      for (let attempt = 1; attempt <= 3 && !switched; attempt++) {
        if (expired()) break;
        await dismissAgreeIfPresent(0);
        editor = findEditor() || editor;
        const modeBtn = findModeButton(editor);
        if (!modeBtn) {
          debug('找不到模式按钮（第 ' + attempt + ' 次）');
          await sleep(400);
          continue;
        }
        lastLabel = txt(modeBtn);
        if (AGENT_RE.test(lastLabel)) {
          switched = true;
          break;
        }
        realClick(modeBtn);
        // 关键：等菜单真的出现再点选项，而不是立刻点
        const item = await waitUntil(findAgentMenuItem, 4000, 120, 'Agent 菜单');
        if (!item) {
          debug('点了模式按钮但菜单没出现（第 ' + attempt + ' 次）');
          await escapeClose();
          continue;
        }
        realClick(item);
        // 验证：按钮文字变成 Agent，或该选项被标记为已选
        switched = !!(await waitUntil(() => agentSelected(findEditor() || editor), 4000, 150, 'Agent 选中态'));
        if (!switched) {
          debug('点了 Agent 但界面没有确认切换（第 ' + attempt + ' 次）');
          await escapeClose();
        }
      }
      if (!switched) {
        report('未能切到 Agent，按当前模式继续（' + (lastLabel || '未知') + '）', 'running', true);
        await sleep(600);
      }
      if (expired()) throw new Error('整体超时，已中止');

      /* 6. 写入提示词：最多 3 轮，每轮重新取输入框、整段校验 */
      let typed = null;
      for (let attempt = 1; attempt <= 3 && !(typed && typed.ok); attempt++) {
        if (expired()) break;
        editor = findEditor();
        if (!editor) {
          await recover();
          await sleep(350);
          continue;
        }
        report('写入提示词…' + (attempt > 1 ? '（第 ' + attempt + ' 轮）' : ''));
        typed = await typeIntoEditor(editor, PROMPT);
        if (!typed.ok) {
          debug('第 ' + attempt + ' 轮写入不完整：' + typed.len + '/' + typed.total);
          await sleep(400);
        }
      }
      if (!typed || !typed.ok) {
        throw new Error('提示词没有完整写进输入框（' + ((typed && typed.len) || 0) + '/' + PROMPT.length + '）');
      }

      /* 7. 发送：每轮都重新确认文本还在、Agree 已清、再把按钮/回车都试一遍 */
      report('准备发送…');
      let sent = { ok: false, how: '' };
      for (let attempt = 1; attempt <= 2 && !sent.ok; attempt++) {
        if (expired()) break;
        await dismissAgreeIfPresent(0);
        editor = findEditor() || editor;
        if (!editor) {
          await recover();
          await sleep(350);
          continue;
        }
        if (editorLength(editor) < Math.ceil(PROMPT.length * 0.9)) {
          const again = await typeIntoEditor(editor, PROMPT);
          if (!again.ok) {
            debug('发送前补写失败：' + again.len + '/' + again.total);
            continue;
          }
        }
        if (attempt > 1) report('第一次没发出去，正在重试…', 'running', true);
        sent = await trySendOnce(editor, sendPath);
        if (!sent.ok) {
          debug('第 ' + attempt + ' 轮发送没有确认成功');
          await escapeClose();
        }
      }
      if (!sent.ok) throw new Error('发送失败：按钮与回车各试了 2 轮，页面仍没有进入会话状态');
      debug('发送成功（' + sent.how + '）');

      /* 8. 先确认成功（界面立刻给反馈），再顺手处理可能出现的 Agree */
      sessionDone = true;
      report('已发送，Arena 正在生成…', 'ok');
      finish('ok', '已发送');
      setBusy(false);

      const handled = await dismissAgreeIfPresent(6000);
      if (handled) {
        debug('发送后的 Agree 已处理');
        report('已发送，并已点掉同意弹窗', 'ok');
      } else {
        debug('发送后没有出现 Agree，未做任何点击');
      }
    } catch (e) {
      const msg = (e && e.message) || String(e);
      report(msg, 'error');
      finish('error', msg);
    } finally {
      disarmWatchdog();
      aborted = false;
      runDeadline = 0;
      running = false;
      if (navigated) setTimeout(() => setBusy(false), 15000);
      else setBusy(false);
    }
  }

  /* ============================================================== 初始化 */

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'LUCKY_RUN') {
      run();
      sendResponse({ ok: true });
      return true;
    }
    return undefined;
  });

  mountUI();
  // 告诉后台“这个页面已经就绪”：若有未完成任务，由后台把 run 交回来（不依赖 onUpdated 时序）
  sendBackground({ type: 'LUCKY_READY' });
})();
